import xlrd, openpyxl

archivo_xls = "clientes.XLS"
archivo_xlsx = "tu_archivo.xlsx"
wb_xls = xlrd.open_workbook(archivo_xls)
sheet_xls = wb_xls.sheet_by_index(0)

wb_xlsx = openpyxl.Workbook()
sheet_xlsx = wb_xlsx.active

for row_idx in range(sheet_xls.nrows):
    row_data = sheet_xls.row_values(row_idx)
    for col_idx, cell_value in enumerate(row_data):
        sheet_xlsx.cell(row=row_idx + 1, column=col_idx + 1, value=cell_value)
wb_xlsx.save(archivo_xlsx)

print(f"Archivo XLS convertido a {archivo_xlsx}")
